import json
import uuid
from datetime import datetime
import os
import time

import boto3
import jwt
import yaml
from botocore.exceptions import ClientError
from kafka import KafkaProducer
import logging
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()

KAFKA_SERVER = os.environ['KAFKA_SERVER'].split(',')
KAFKA_TOPIC = os.environ['KAFKA_TOPIC']

secret_name = os.environ['SECRETS_MANAGER_SECRET_NAME']
region_name = os.environ['AWS_REGION']

session = boto3.session.Session()
client = session.client(
    service_name='secretsmanager',
    region_name=region_name
)

# Global variables for caching
jwt_public_key = None
jwt_key_last_fetched = 0
JWT_KEY_CACHE_DURATION = 3600  # 1 hour

# Global producer for reuse
producer = KafkaProducer(
    bootstrap_servers=KAFKA_SERVER,
    value_serializer=lambda x: json.dumps(x).encode('utf-8')
)


def get_jwt_public_key():
    global jwt_public_key, jwt_key_last_fetched
    current_time = time.time()

    if jwt_public_key and (current_time - jwt_key_last_fetched) < JWT_KEY_CACHE_DURATION:
        return jwt_public_key

    secrets = client.get_secret_value(SecretId=secret_name)
    secret_dict = yaml.safe_load(secrets['SecretString'])

    jwt_public_key = secret_dict['JWT_ACCESS_TOKEN_PUBLIC_KEY']
    jwt_key_last_fetched = current_time
    return jwt_public_key


def send_to_kafka(topic: str, data: dict) -> None:
    try:
        future = producer.send(topic, value=data)
        result = future.get(timeout=10)
        logger.info(f"Message sent to {result.topic} partition {result.partition} offset {result.offset}")
    except Exception as e:
        logging.error(f"Failed to send message: {e}")
        raise e
    finally:
        producer.flush()


def event(event, context):
    auth_header = event.get('headers', {}).get('Authorization')
    if not auth_header:
        raise Exception(json.dumps({
            'statusCode': 401,
            'body': json.dumps({'message': 'No auth header'})
        }))

    if len(auth_header.split(" ")) != 2:
        raise Exception(json.dumps({
            'statusCode': 401,
            'body': json.dumps({'message': 'Invalid token'})
        }))

    encoded_jwt = auth_header.split(" ")[1]
    try:
        key = get_jwt_public_key()
        decoded_jwt = jwt.decode(encoded_jwt, key, algorithms=['ES256'])
        jwt_data = {
            "sdk": decoded_jwt.get('sdk'),
            "version": decoded_jwt.get('version'),
            "hostname": decoded_jwt.get('hostname'),
            "source": decoded_jwt.get('source'),
        }
    except ClientError as e:
        raise Exception(json.dumps({
            'statusCode': 500,
            'body': json.dumps({'message': 'aws error, ' + str(e)})
        }))
    except jwt.ExpiredSignatureError:
        raise Exception(json.dumps({
            'statusCode': 401,
            'body': json.dumps({'message': 'Token expired'})
        }))
    except jwt.InvalidTokenError as e:
        raise Exception(json.dumps({
            'statusCode': 401,
            'body': json.dumps({'message': f'Invalid token: {str(e)}'})
        }))

    if 'body' not in event:
        raise Exception(json.dumps({
            'statusCode': 400,
            'body': json.dumps({'message': 'Bad Request: No body in request'})
        }))

    event_data = event['body'].get('event_data')
    if not event_data:
        raise Exception(json.dumps({
            'statusCode': 400,
            'body': json.dumps({'message': 'Bad Request: No event data in request'})
        }))

    required_fields = ['event', 'client_id', 'session', 'timestamp']
    missing_fields = [field for field in required_fields if not event_data.get(field)]

    if missing_fields:
        raise Exception(json.dumps({
            'statusCode': 400,
            'body': json.dumps({'message': f'Bad Request: Missing required fields: {", ".join(missing_fields)}'})
        }))
    try:
        ts = int(event_data["timestamp"])
        # timestamp should be in milliseconds
        if len(str(ts)) != 13 or ts < 946684800000 or ts > 4102444800000:
            raise ValueError("Timestamp must be in milliseconds")
        ts = ts // 1000
        time_string = datetime.fromtimestamp(ts).isoformat(sep='T', timespec='milliseconds')
    except Exception as e:
        raise Exception(json.dumps({
            'statusCode': 400,
            'body': json.dumps({'message': 'Bad Request: Invalid timestamp, ' + str(e)})
        }))
    kafka_data = {
        "event_id": str(uuid.uuid4()),
        "client_id": event_data.get("client_id"),
        "event_name": event_data.get("event"),
        "event_properties": {k: v if v is not None else "null" for k, v in
                             event_data.get("event_properties", {}).items()},
        "user_properties": {k: v if v is not None else "null" for k, v in
                            event_data.get("user_properties", {}).items()},
        "meta_properties": {
            "location": event_data.get("location", {}),
            "device": event_data.get("device", {})
        },
        "timestamp": time_string,
        "referrer": event_data.get("referrer"),
        "session": event_data.get("session"),
        "utm_parameters": {k: v if v is not None else "null" for k, v in event_data.get("utm_params", {}).items()},
        "channel": {k: v if v is not None else "null" for k, v in jwt_data.items()}
    }
    try:
        logger.info(f"JSON body: {kafka_data}")
        send_to_kafka(KAFKA_TOPIC, kafka_data)
    except json.JSONDecodeError:
        logger.error("Error decoding JSON")
        raise Exception(json.dumps({
            'statusCode': 400,
            'body': json.dumps({'message': 'Bad Request: Malformed JSON'})
        }))
    except Exception as e:
        logger.error(f"Failed to push message to Kafka: {e}")
        raise Exception(json.dumps({
            'statusCode': 500,
            'body': json.dumps({'message': 'Failed to push msg to kafka' + str(e)}),
        }))

    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Success'
        })
    }
